// Exception catch for if the user drives a piece to an already occupied square.

public class AlreadyOccupiedException extends RuntimeException {
	public AlreadyOccupiedException(String msg) {
		super(msg);
	}
}